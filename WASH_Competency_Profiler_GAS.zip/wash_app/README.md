# Impact WaterWorks WASH Competency Profiler — Google Apps Script implementation

## Source audit and important limitation

The supplied PDF is a four-page workbook specification, not the full humanitarian competency framework. It describes a *different* 24-item sample workbook (six themes × four items) and a five-level scale whose labels are **Not Competent, Basic Awareness, Perform with Support, Perform Independently, Lead, Design & Mentor**. The supplied XLSX is the Impact WaterWorks web-app-style profiler: it specifies 219 competencies across six domains and uses the requested UI labels **Novice, Developing, Proficient, Advanced, Expert** plus the five importance choices. The implementation follows the XLSX UI scales and domain totals, and uses the PDF only as context.

**The XLSX supplied here is visibly incomplete as a competency bank.** It declares 66/28/14/38/30/43 items (219 total), but only a partial set of statements is present as extractable cell text. This package seeds the question bank with the 43 distinct source-visible statements extracted from the XLSX; it does not invent the missing 176 statements. Some source codes/text have OCR-like irregularities (for example O/0, quote marks, and missing characters), retained in the `Source_Code_As_Seen` and `Competency_Statement_As_Seen` columns for traceability. Do not deploy for official assessment until the missing statements and codes have been recovered from the authoritative source and verified.

## Files
- `Code.gs` — workbook setup, data service, app entry point, seed data.
- `Index.html` — responsive assessment UI, browser-local saving/resume, ratings, summary, charts and CSV export.
- `seed.json` — audit-friendly extracted source-visible items with original sheet/row references.

## Install
1. Create a new Google Spreadsheet.
2. Open **Extensions → Apps Script**. Replace the default script with `Code.gs`. Add an HTML file named **Index** and paste `Index.html`.
3. Save. In Apps Script, choose `setupWorkbook` and click **Run**. Approve the spreadsheet permissions. This creates `README`, `Question_Bank`, `Rating_Scales`, `Responses`, and `Domain_Summary` sheets. `Question_Bank` is seeded from the extractable source-visible items.
4. Return to the spreadsheet and review `Question_Bank`. Add verified missing rows with columns `Item_ID`, `Domain`, `Source_Code_As_Seen`, `Competency_Statement_As_Seen`, `Source_Sheet`, `Source_Row`, `Data_Status`. Use one unique ID per competency. Keep the six domain names exactly as listed in the workbook. Do not use fabricated statements.
5. In Apps Script, **Deploy → New deployment → Web app**. Execute as **Me**. Set access to **Anyone** if this is intended to be public and your Google Workspace policy permits it. Deploy and open the URL.
6. If you change `Question_Bank`, reload the web app. The app reads the live sheet each time it opens.

## Scoring and local persistence
- Competence: Novice=1, Developing=2, Proficient=3, Advanced=4, Expert=5.
- Importance: Not important=1, Slightly=2, Moderate=3, Very important=4, Critical=5.
- A competency contributes to scoring only when it is not marked N/A and both ratings are present.
- Domain average competence and importance are arithmetic means of applicable fully rated items.
- Priority score is implemented as `average importance × (6 − average competence)` (range 1–25). The source XLSX names a priority score but does not expose its exact formula in the supplied extract; this formula is an explicit implementation assumption and should be confirmed against the authoritative source.
- Domain profile charts appear only for domains with at least one fully rated applicable item.
- Responses are stored in browser `localStorage`, not sent to Sheets. This follows the XLSX welcome-screen statement that no account is required and responses are saved locally. Clearing browser storage or switching browsers/devices removes/does not transfer saved progress. The spreadsheet's `Responses` tab is a schema placeholder and is not populated by the client.

## Testing checklist
1. Run `setupWorkbook`; confirm all five sheets and validation rules are created.
2. Deploy as a web app and open the URL. Confirm all six domains and purpose options render.
3. Select a domain with seeded items; rate competence and importance, mark another N/A, then Save & exit. Reload and Resume; confirm saved values persist.
4. Complete ratings and view results. Confirm N/A is excluded, averages use only fully rated items, and charts only appear for domains with rated applicable items.
5. Export CSV and verify domain summary and item-level ratings.
6. Add a verified test item to `Question_Bank`, reload the app, and confirm it appears.
7. Before production, reconcile the question bank to exactly 219 verified source items, verify every code/statement and decide whether the priority formula matches the original app.

## Known functional notes
- This is a client-side browser-local app backed by a Sheets question bank; it does not transmit personal assessment responses to Google Sheets.
- There is no account/login requirement. A browser's localStorage is not a cross-device resume service.
- The app is executable with the supplied files, but content fidelity to all 219 competencies cannot be claimed until the incomplete source bank is repaired.
