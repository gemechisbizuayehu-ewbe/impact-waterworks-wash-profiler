# WaSH Competency Profiler — revised for the supplied Google Sheet

Target spreadsheet: `1XqqkZtJeSTXhwb-jj7B85pVk9JTyLFDE7ngMRRd4KwM`

## What changed
- `Code.gs` opens the configured spreadsheet by ID; it no longer assumes `getActive()` points at the right file.
- It no longer requires exact sheet names `Question_Bank`, `Rating_Scales`, or `Lists_and_Lookups` just to start.
- It scans the first 40 rows of each sheet for recognizable question headers, accepts common header aliases, and can read a master bank or domain tabs.
- `setupWorkbook()` reports detected item counts and diagnostics rather than hard-failing just because a tab is named differently or the item count isn't exactly 219.
- `getWorkbookDiagnostics()` reports sheet names, dimensions, detected items, domain counts, and scan messages.
- The HTML error screen shows the server diagnostic rather than only saying that `Question_Bank` is missing.
- Responses remain in browser `localStorage`; no responses are written to Sheets.

## Install/update
1. Open the exact spreadsheet URL supplied by the user.
2. Choose **Extensions → Apps Script**. If the Apps Script project is standalone rather than bound, the code still opens the target by ID, but ensure the account executing the script has access to the spreadsheet.
3. Replace `Code.gs` with the supplied revised file.
4. Replace the existing HTML file named `Index` with the supplied revised `Index.html` content. Keep the file name `Index` (Apps Script appends `.html`).
5. Save the project.
6. Run `getWorkbookDiagnostics()` first and authorize if prompted. Inspect its output for the actual tab names and detected item count.
7. Run `setupWorkbook()`. It should report the spreadsheet name, detected count, domain counts, and source scan.
8. Deploy using **Deploy → Manage deployments → Edit** to update the existing web app, or create a new web app deployment. Use **Execute as: Me** and an access setting allowed by your Workspace policy.
9. Open the deployed URL and test a single domain, ratings, N/A, local resume, results, and charts.

## Source header detection
The code looks for a header row with a statement-like field (`Assessment_Statement`, `Assessment Question`, `Question`, `Statement`, or `Competency_Description`) plus an identity/code field. Domain identity is inferred from theme/domain labels, sheet names, and common item-code prefixes: CORE, HP, VC, EM/SAN, SWS/WAT, SWM.

If diagnostics report zero items, inspect the actual sheet and adjust the alias list in `readSheetRows_()` or the mapping in `domainFrom_()`. This is preferable to silently inventing competency content. Rows without a detectable domain are intentionally skipped. A master Question_Bank is preferred; when found, other domain tabs are not merged to avoid duplicates.

## Important notes
- This code reads source values and does not rewrite competency statements or workbook tabs.
- The app does not require `Rating_Scales` or `Lists_and_Lookups` to exist because the online labels are explicitly defined in the app requirements.
- Domain counts are discovered from the spreadsheet. If the actual sheet differs from the source XLSX, diagnostics make the difference visible rather than requiring a hard-coded count.
- The web app has not been deployed into the user's account from this session. Run the diagnostics and verify the live spreadsheet structure before production use.
