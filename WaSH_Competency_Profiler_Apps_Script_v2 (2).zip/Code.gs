/** Impact WaterWorks WaSH Competency Profiler — resilient source discovery.
 * Bound or standalone Apps Script is supported. Responses remain browser-local.
 */
const CONFIG = {
  SPREADSHEET_ID: '1XqqkZtJeSTXhwb-jj7B85pVk9JTyLFDE7ngMRRd4KwM',
  APP_TITLE: 'WaSH Competency Profiler',
  VERSION: '2.0.0',
  EXPECTED_TOTAL: 219
};

function doGet() {
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle(CONFIG.APP_TITLE)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

function getSourceSpreadsheet_() {
  // Explicit ID avoids relying on whichever spreadsheet happens to be active.
  try { return SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID); }
  catch (e) {
    const active = SpreadsheetApp.getActiveSpreadsheet();
    if (active && active.getId() === CONFIG.SPREADSHEET_ID) return active;
    throw new Error('Cannot open the configured spreadsheet. Check that this Apps Script project has access to spreadsheet ID ' + CONFIG.SPREADSHEET_ID + '. Original error: ' + e.message);
  }
}

function norm_(v) {
  return String(v == null ? '' : v).toLowerCase().trim()
    .replace(/[\u2010-\u2015]/g, '-')
    .replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
}
function cell_(row, aliases) {
  for (let i = 0; i < aliases.length; i++) {
    const target = norm_(aliases[i]);
    for (let j = 0; j < row.length; j++) if (norm_(row[j]) === target) return j;
  }
  return -1;
}
function domainFrom_(code, name, sheetName, itemCode) {
  const all = [code, name, sheetName, itemCode].map(norm_).join(' ');
  if (/(^|\s|_)core(\s|_|$)|humanitarian.*wash|core_humanitarian/.test(all) || /^core/.test(norm_(itemCode))) return 'CORE';
  if (/hygiene|promotion|community_engagement/.test(all) || /^hp[-_]/i.test(String(itemCode))) return 'HP';
  if (/vector|mosquito|environmental_health/.test(all) || /^vc[-_]/i.test(String(itemCode))) return 'VC';
  if (/excreta|sanitation|latrine/.test(all) || /^em[-_]|^san[-_]/i.test(String(itemCode))) return 'EM';
  if (/safe_water|water_supply|water_treatment|water_quality/.test(all) || /^sws[-_]|^wat[-_]/i.test(String(itemCode))) return 'SWS';
  if (/solid_waste|waste_management|healthcare_waste/.test(all) || /^swm[-_]/i.test(String(itemCode))) return 'SWM';
  return '';
}
function domainName_(code) {
  return ({CORE:'Core humanitarian WASH competencies',HP:'Hygiene promotion',VC:'Vector control',EM:'Excreta management',SWS:'Safe water supply',SWM:'Solid Waste Management'})[code] || code || 'Unclassified';
}
function findHeader_(grid) {
  let best = null;
  const max = Math.min(grid.length, 40);
  for (let r = 0; r < max; r++) {
    const row = grid[r].map(norm_);
    const hasStatement = row.some(x => ['assessment_statement','assessment_question','statement','question','competency_description','competency'].includes(x));
    const hasIdentity = row.some(x => ['record_id','item_id','competency_code','code','competency_name'].includes(x));
    if (hasStatement && hasIdentity) {
      const score = (hasStatement ? 3 : 0) + (hasIdentity ? 2 : 0) + (row.some(x => ['theme_code','domain','theme','theme_name'].includes(x)) ? 1 : 0);
      if (!best || score > best.score) best = {row:r, headers:grid[r], score:score};
    }
  }
  return best;
}
function readSheetRows_(sheet) {
  const grid = sheet.getDataRange().getDisplayValues();
  const found = findHeader_(grid);
  if (!found) return {questions:[],diagnostic:sheet.getName()+': no recognizable question header row'};
  const h = found.headers;
  const idx = {
    record:cell_(h,['Record_ID','Record ID','Record']), themeCode:cell_(h,['Theme_Code','Theme Code','Domain_Code','Domain Code','Theme']),
    themeName:cell_(h,['Theme_Name','Theme Name','Domain_Name','Domain Name','Domain']), sectionCode:cell_(h,['Section_Code','Section Code']),
    sectionName:cell_(h,['Section_Name','Section Name']), compCode:cell_(h,['Competency_Code','Competency Code','Competency_ID','Code']),
    compName:cell_(h,['Competency_Name','Competency Name','Competency']), description:cell_(h,['Competency_Description','Competency Description','Description']),
    id:cell_(h,['Item_ID','Item ID','Question_ID','Question ID','Record_ID','Record ID']),
    statement:cell_(h,['Assessment_Statement','Assessment Statement','Assessment_Question','Assessment Question','Question','Statement','Competency_Description','Competency Description']),
    instruction:cell_(h,['Assessment_Instruction','Assessment Instruction','Instructions']),
    required:cell_(h,['Required_Status','Required Status']), logic:cell_(h,['Conditional_Logic','Conditional Logic'])
  };
  if (idx.statement < 0) return {questions:[],diagnostic:sheet.getName()+': found headers but no statement column'};
  const out=[];
  for (let r=found.row+1;r<grid.length;r++) {
    const row=grid[r];
    const statement=String(row[idx.statement]||'').trim();
    if (!statement) continue;
    const itemCode=idx.id>=0?String(row[idx.id]||'').trim():'';
    const compCode=idx.compCode>=0?String(row[idx.compCode]||'').trim():'';
    const themeCodeRaw=idx.themeCode>=0?String(row[idx.themeCode]||'').trim():'';
    const themeNameRaw=idx.themeName>=0?String(row[idx.themeName]||'').trim():'';
    const domain=domainFrom_(themeCodeRaw,themeNameRaw,sheet.getName(),compCode||itemCode);
    // Avoid treating summary or lookup rows as competencies.
    if (!domain) continue;
    const id=itemCode||compCode||('ITEM-'+String(out.length+1).padStart(3,'0'));
    out.push({id:id,recordId:idx.record>=0?String(row[idx.record]||id):id,themeCode:domain,themeName:domainName_(domain),
      sectionCode:idx.sectionCode>=0?String(row[idx.sectionCode]||''):'',sectionName:idx.sectionName>=0?String(row[idx.sectionName]||''):'',
      competencyCode:compCode||id,competencyName:idx.compName>=0?String(row[idx.compName]||''):statement,
      statement:statement,instruction:idx.instruction>=0?String(row[idx.instruction]||'Rate current competence and importance to your role.'):'Rate current competence and importance to your role.',
      requiredStatus:idx.required>=0?String(row[idx.required]||'Required when applicable'):'Required when applicable',
      conditionalLogic:idx.logic>=0?String(row[idx.logic]||'Not Applicable excludes the item from scoring and charts.'):'Not Applicable excludes the item from scoring and charts.',_sourceSheet:sheet.getName(),_sourceRow:r+1});
  }
  return {questions:out,diagnostic:sheet.getName()+': '+out.length+' question rows detected (header row '+(found.row+1)+')'};
}
function collectQuestions_() {
  const ss=getSourceSpreadsheet_(), sheets=ss.getSheets(), diagnostics=[], all=[];
  // Prefer a recognizable master bank. Otherwise aggregate the domain tabs.
  const bankNames=['question_bank','question bank','questionbank','competency_bank','competency bank','assessment_items','assessment items'];
  const bankSheets=sheets.filter(s=>bankNames.includes(norm_(s.getName()).replace(/_/g,' ')) || bankNames.includes(norm_(s.getName())));
  const ordered=bankSheets.concat(sheets.filter(s=>!bankSheets.includes(s)));
  for (const sh of ordered) {
    const result=readSheetRows_(sh); diagnostics.push(result.diagnostic);
    if (result.questions.length) {
      all.push.apply(all,result.questions);
      // A valid master bank is preferred; don't double count the domain tabs.
      if (bankSheets.includes(sh)) break;
    }
  }
  // Deduplicate by item ID + normalized statement, preserving first source occurrence.
  const seen={}, unique=[];
  all.forEach(q=>{const key=norm_(q.id)+'|'+norm_(q.statement);if(!seen[key]){seen[key]=true;unique.push(q);}});
  const domainOrder=['CORE','HP','VC','EM','SWS','SWM'];
  unique.sort((a,b)=>domainOrder.indexOf(a.themeCode)-domainOrder.indexOf(b.themeCode) || String(a.id).localeCompare(String(b.id),undefined,{numeric:true}));
  return {ss:ss,questions:unique,diagnostics:diagnostics};
}
function setupWorkbook() {
  const result=collectQuestions_();
  const counts={}; result.questions.forEach(q=>counts[q.themeCode]=(counts[q.themeCode]||0)+1);
  if (!result.questions.length) {
    throw new Error('No competency statements could be detected in spreadsheet "'+result.ss.getName()+'". Sheet tabs: '+result.ss.getSheets().map(s=>s.getName()).join(', ')+'. Detection log: '+result.diagnostics.join(' | ')+'. Ensure a header row contains a statement/question/competency-description column and a code/ID column, and that domain or theme labels identify one of the six domains.');
  }
  PropertiesService.getScriptProperties().setProperty('WASH_SETUP_VERSION',CONFIG.VERSION);
  PropertiesService.getScriptProperties().setProperty('WASH_SOURCE_SHEET_ID',result.ss.getId());
  return 'Setup verified. Spreadsheet: '+result.ss.getName()+'. Detected '+result.questions.length+' items. Domain counts: '+JSON.stringify(counts)+'. Source scan: '+result.diagnostics.filter(x=>!x.includes('0 question rows')).join(' | ');
}
function getAppData() {
  const result=collectQuestions_();
  if (!result.questions.length) throw new Error('No assessment items found. '+result.diagnostics.join(' | '));
  const domains=[{code:'CORE',name:domainName_('CORE')},{code:'HP',name:domainName_('HP')},{code:'VC',name:domainName_('VC')},{code:'EM',name:domainName_('EM')},{code:'SWS',name:domainName_('SWS')},{code:'SWM',name:domainName_('SWM')}]
    .map(d=>Object.assign(d,{count:result.questions.filter(q=>q.themeCode===d.code).length})).filter(d=>d.count>0);
  return {title:CONFIG.APP_TITLE,version:CONFIG.VERSION,spreadsheetName:result.ss.getName(),questions:result.questions,domains:domains,
    competence:['Novice','Developing','Proficient','Advanced','Expert'],importance:['Not important','Slightly','Moderate','Very important','Critical'],
    competenceValues:[1,2,3,4,5],importanceValues:[1,2,3,4,5],diagnostics:result.diagnostics};
}
function getWorkbookDiagnostics() {
  const ss=getSourceSpreadsheet_(), result=collectQuestions_();
  return {spreadsheetName:ss.getName(),spreadsheetId:ss.getId(),sheets:ss.getSheets().map(s=>({name:s.getName(),rows:s.getLastRow(),columns:s.getLastColumn()})),detectedItems:result.questions.length,domainCounts:result.questions.reduce((a,q)=>(a[q.themeCode]=(a[q.themeCode]||0)+1,a),{}),scan:result.diagnostics};
}
